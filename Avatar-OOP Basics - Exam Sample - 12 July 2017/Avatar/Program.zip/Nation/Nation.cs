﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public abstract class Nation
{
    public List<Bender> Benders { get; set; }
    public List<Monument> Monuments { get; set; }

    public Nation()
    {
        this.Benders = new List<Bender>();
        this.Monuments = new List<Monument>();
    }
}