﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class FireMonument : Monument
{
    public int FireAffinity  { get; set; }

    public FireMonument(string name, int fireAffinity) : base(name)
    {
        FireAffinity = fireAffinity;
    }
}
