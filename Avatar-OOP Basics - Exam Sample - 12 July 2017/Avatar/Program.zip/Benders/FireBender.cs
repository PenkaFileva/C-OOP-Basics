﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class FireBender : Bender
{
    public double HeatAggression  { get;  }

    public FireBender(string name, int power, double heatAggression) : base(name, power)
    {
        HeatAggression = heatAggression;
    }
}
